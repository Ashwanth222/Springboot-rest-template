package com.example.springbootresttemplate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootResttemplateApplicationTests {

    @Test
    void contextLoads() {
    }

}
