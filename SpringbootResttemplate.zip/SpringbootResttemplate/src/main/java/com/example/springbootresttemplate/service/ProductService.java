package com.example.springbootresttemplate.service;

public class ProductService {
}
