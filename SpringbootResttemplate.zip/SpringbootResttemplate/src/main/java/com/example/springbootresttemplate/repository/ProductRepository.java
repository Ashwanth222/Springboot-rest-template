package com.example.springbootresttemplate.repository;

public interface ProductRepository {
}
